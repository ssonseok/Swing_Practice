
public class Account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			String ownerName;
			int balance;
			
			public void setOwnerName(String name) {
				ownerName = name;				
			}
			public void setBalance(int amount) {
				balance = amount;				
			}
			public void deposit(int amount) {
				balance = balance + amount;				
			}
			public void withdraw(int amount) {
				balance = balance - amount;				
			}
	}
	
}
	public String getOwnerName() {
		return (ownerName);		
	}
	
	public String getBalance() {
		return (balance);		
	}
	
	public String toString() {
		String result="";
		result=result="������ �̸�"+getOwnerName()+"n";
		result=result+"�ܰ�"+getBalance();
		return resultString;
	}
}
	public class Driver{
		public static void main (String[] args) {
			Account acct;
			Account acct=new Account();
			acct.setOwnerName("����");
			acct.setBalance(0);
			acct.deposit(100000);
			acct.withdraw(20000);
			System.out.println(acct.toString());
			}
	}